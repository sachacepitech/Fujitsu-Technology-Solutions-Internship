var searchData=
[
  ['init_5fstruct_5fdb_5fand_5fdevice_2ec_0',['init_struct_db_and_device.c',['../init__struct__db__and__device_8c.html',1,'']]],
  ['init_5fusb_5fenumerator_2ec_1',['init_usb_enumerator.c',['../init__usb__enumerator_8c.html',1,'']]]
];
