var searchData=
[
  ['product_5fid_0',['PRODUCT_ID',['../druid_8h.html#a6b41096e44c646df97fba9581acb4b4a',1,'druid.h']]],
  ['product_5fname_1',['PRODUCT_NAME',['../druid_8h.html#a2fd81ded1b6a151f629441182c358d5b',1,'druid.h']]]
];
