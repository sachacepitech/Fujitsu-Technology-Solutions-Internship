var searchData=
[
  ['data_5fusb_5fcon_5fs_0',['data_usb_con_s',['../structdata__usb__con__s.html',1,'']]]
];
