var searchData=
[
  ['major_0',['major',['../structusb__risk__stats__s.html#aba8124d6ea55ba08779fba681dda214e',1,'usb_risk_stats_s']]],
  ['medium_1',['medium',['../structusb__risk__stats__s.html#a481a5fe80c802914aaac38c1ab4196a8',1,'usb_risk_stats_s']]]
];
