var searchData=
[
  ['get_5fvendor_5fproduct_5fdevice_0',['get_vendor_product_device',['../scan__connected__usb__and__check__risks_8c.html#acb3f59444a828be9d0172449360aa6cd',1,'scan_connected_usb_and_check_risks.c']]]
];
