var searchData=
[
  ['add_5fnew_5fdata_0',['add_new_data',['../load__usb__db__from__file_8c.html#a914492188633dfc94580aa4a17d9bc1a',1,'load_usb_db_from_file.c']]],
  ['add_5fto_5fseen_1',['add_to_seen',['../scan__connected__usb__and__check__risks_8c.html#aaff737479e6d2fb08c4be5cda02b1e84',1,'scan_connected_usb_and_check_risks.c']]],
  ['append_5fusb_5fentry_5ffrom_5fline_2',['append_usb_entry_from_line',['../load__usb__db__from__file_8c.html#a8103a7afd0401b23ac2df003008a9c55',1,'load_usb_db_from_file.c']]]
];
