var searchData=
[
  ['device_0',['device',['../structusb__tools__s.html#abe2ea70e78755038de5ec86eb65ed4c1',1,'usb_tools_s']]]
];
