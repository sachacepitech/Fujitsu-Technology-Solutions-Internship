var searchData=
[
  ['vendor_5fid_0',['vendor_id',['../structusb__db__entry__s.html#a73f47ae0f7d0ed50c56505b044790bb3',1,'usb_db_entry_s::vendor_id'],['../structdata__usb__con__s.html#a65d7085524675aef9da84832b6bebbf0',1,'data_usb_con_s::vendor_id'],['../structseen__device__s.html#a65d7085524675aef9da84832b6bebbf0',1,'seen_device_s::vendor_id'],['../druid_8h.html#a5e2fdecfea0fad3bdb8fa4eedf041a3d',1,'VENDOR_ID:&#160;druid.h']]],
  ['vendor_5fname_1',['vendor_name',['../structusb__db__entry__s.html#aff2f2dfb4e9f9fe4d5f9fd543b71dd08',1,'usb_db_entry_s::vendor_name'],['../structdata__usb__con__s.html#a8b2e2304dc1e7d195e418499854eaa6a',1,'data_usb_con_s::vendor_name'],['../druid_8h.html#a5251bd72c4fbf8bfaa8063771f58254e',1,'VENDOR_NAME:&#160;druid.h']]]
];
