var searchData=
[
  ['scan_5fconnected_5fusb_5fand_5fcheck_5frisks_2ec_0',['scan_connected_usb_and_check_risks.c',['../scan__connected__usb__and__check__risks_8c.html',1,'']]],
  ['seen_5fdevices_2eh_1',['seen_devices.h',['../seen__devices_8h.html',1,'']]]
];
