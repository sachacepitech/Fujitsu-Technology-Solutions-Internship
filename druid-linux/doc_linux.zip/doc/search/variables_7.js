var searchData=
[
  ['seen_5fcount_0',['seen_count',['../structusb__risk__stats__s.html#a624cd3f526b800ef7c72683253b23d15',1,'usb_risk_stats_s']]],
  ['seen_5fdevices_1',['seen_devices',['../seen__devices_8h.html#a51efe93a7bf9fc4e8184a4eb68234477',1,'seen_devices.h']]]
];
