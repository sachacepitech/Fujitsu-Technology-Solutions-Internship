var searchData=
[
  ['read_5fmode_0',['READ_MODE',['../druid_8h.html#a064cc7153fdb5596b2079d865dd9e055',1,'druid.h']]],
  ['remove_5fnewline_1',['remove_newline',['../load__usb__db__from__file_8c.html#a429655f2ccd8312615d99eae8a30dca4',1,'load_usb_db_from_file.c']]]
];
