var searchData=
[
  ['license_5ffile_0',['LICENSE_FILE',['../druid_8h.html#a6cc71f8e74ae9358e065105fc6af995e',1,'druid.h']]],
  ['license_5fflag_1',['LICENSE_FLAG',['../druid_8h.html#a49c96f5ff710aec125759adbe3c8d47c',1,'druid.h']]],
  ['license_5fflag_5foption_2',['LICENSE_FLAG_OPTION',['../druid_8h.html#ae83340947ef97682cd71a7b4d0622b44',1,'druid.h']]]
];
