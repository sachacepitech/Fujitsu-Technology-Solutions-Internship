var searchData=
[
  ['max_5fseen_5fdevices_0',['MAX_SEEN_DEVICES',['../seen__devices_8h.html#a6fd0106cd2eb2ec04b268fa65cce1b42',1,'seen_devices.h']]]
];
