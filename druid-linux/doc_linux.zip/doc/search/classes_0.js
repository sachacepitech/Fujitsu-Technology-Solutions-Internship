var searchData=
[
  ['cli_5fargs_5fs_0',['cli_args_s',['../structcli__args__s.html',1,'']]]
];
