var searchData=
[
  ['main_0',['main',['../main_8c.html#a0c99d968a34e803d378692bde2e3f18f',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['major_2',['major',['../structusb__risk__stats__s.html#aba8124d6ea55ba08779fba681dda214e',1,'usb_risk_stats_s']]],
  ['max_5fseen_5fdevices_3',['MAX_SEEN_DEVICES',['../seen__devices_8h.html#a6fd0106cd2eb2ec04b268fa65cce1b42',1,'seen_devices.h']]],
  ['medium_4',['medium',['../structusb__risk__stats__s.html#a481a5fe80c802914aaac38c1ab4196a8',1,'usb_risk_stats_s']]]
];
