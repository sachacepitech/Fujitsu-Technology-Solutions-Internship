var searchData=
[
  ['scan_5fconnected_5fusb_5fand_5fcheck_5frisks_0',['scan_connected_usb_and_check_risks',['../druid_8h.html#a7ead81cba041d6ec565cc01a7a959760',1,'scan_connected_usb_and_check_risks(usb_tools_t *usb_tools, usb_device_info_t *usb_device_info, usb_db_entry_t *usb_db_entry, cli_args_t *cli_args):&#160;scan_connected_usb_and_check_risks.c'],['../scan__connected__usb__and__check__risks_8c.html#a7ead81cba041d6ec565cc01a7a959760',1,'scan_connected_usb_and_check_risks(usb_tools_t *usb_tools, usb_device_info_t *usb_device_info, usb_db_entry_t *usb_db_entry, cli_args_t *cli_args):&#160;scan_connected_usb_and_check_risks.c']]]
];
