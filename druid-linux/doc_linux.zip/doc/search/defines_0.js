var searchData=
[
  ['data_5ffile_5fpath_0',['DATA_FILE_PATH',['../druid_8h.html#a5d52c8ea5f2ffec1ad2239fc02f3087c',1,'druid.h']]],
  ['default_5fsize_1',['DEFAULT_SIZE',['../druid_8h.html#a9771cabfd673a8e350f1f8ce0b8f458f',1,'druid.h']]]
];
