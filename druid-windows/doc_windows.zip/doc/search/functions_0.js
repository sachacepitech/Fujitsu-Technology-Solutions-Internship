var searchData=
[
  ['add_5fnew_5fdata_0',['add_new_data',['../load__usb__db__from__file_8c.html#ab06c98c5c590ea62fc00838d34465d3e',1,'load_usb_db_from_file.c']]],
  ['add_5fto_5fseen_1',['add_to_seen',['../scan__connected__usb__and__check__risks_8c.html#af8ed0fded1bf9983d2d9cc8325183486',1,'scan_connected_usb_and_check_risks.c']]],
  ['append_5fusb_5fentry_5ffrom_5fline_2',['append_usb_entry_from_line',['../load__usb__db__from__file_8c.html#abec0ee57c909e115d0648599f58d0682',1,'load_usb_db_from_file.c']]]
];
