var searchData=
[
  ['device_5finfo_5fset_0',['device_info_set',['../structusb__tools__s.html#aeabfac93ae4a68cc10a85e3fec23f878',1,'usb_tools_s']]]
];
