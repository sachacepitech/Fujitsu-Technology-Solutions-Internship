var searchData=
[
  ['main_0',['main',['../main_8c.html#a0c99d968a34e803d378692bde2e3f18f',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['major_2',['major',['../structusb__risk__stats__s.html#aa53cf53c0a68f5a2ddde8d0990ee896f',1,'usb_risk_stats_s']]],
  ['max_5fseen_5fdevices_3',['MAX_SEEN_DEVICES',['../seen__devices_8h.html#a6fd0106cd2eb2ec04b268fa65cce1b42',1,'seen_devices.h']]],
  ['medium_4',['medium',['../structusb__risk__stats__s.html#a972f3e21f5895ab975db2dc3b7318cbc',1,'usb_risk_stats_s']]]
];
