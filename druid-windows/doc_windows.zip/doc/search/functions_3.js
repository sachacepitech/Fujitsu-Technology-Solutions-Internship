var searchData=
[
  ['extract_5fvendor_5fand_5fproduct_5fids_5ffrom_5fhardware_5fid_0',['extract_vendor_and_product_ids_from_hardware_id',['../druid_8h.html#abace7132af780810be48635a307180f2',1,'extract_vendor_and_product_ids_from_hardware_id(const char *hardware_id, char *vendor_id, char *product_id):&#160;enum_windows_device_details.c'],['../enum__windows__device__details_8c.html#abace7132af780810be48635a307180f2',1,'extract_vendor_and_product_ids_from_hardware_id(const char *hardware_id, char *vendor_id, char *product_id):&#160;enum_windows_device_details.c']]]
];
