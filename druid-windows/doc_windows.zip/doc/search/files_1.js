var searchData=
[
  ['enum_5fwindows_5fdevice_5fdetails_2ec_0',['enum_windows_device_details.c',['../enum__windows__device__details_8c.html',1,'']]]
];
