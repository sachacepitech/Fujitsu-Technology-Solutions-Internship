var searchData=
[
  ['index_0',['index',['../structusb__tools__s.html#a2a94042027892d5d3ad23bac2d7d8207',1,'usb_tools_s']]],
  ['interface_5fdata_1',['interface_data',['../structusb__tools__s.html#a08654b80550b04115ac3065d791d7f83',1,'usb_tools_s']]]
];
