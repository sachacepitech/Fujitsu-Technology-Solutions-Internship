var searchData=
[
  ['vendor_5fid_0',['VENDOR_ID',['../druid_8h.html#a5e2fdecfea0fad3bdb8fa4eedf041a3d',1,'druid.h']]],
  ['vendor_5fname_1',['VENDOR_NAME',['../druid_8h.html#a5251bd72c4fbf8bfaa8063771f58254e',1,'druid.h']]]
];
