var searchData=
[
  ['seen_5fdevice_5fs_0',['seen_device_s',['../structseen__device__s.html',1,'']]]
];
