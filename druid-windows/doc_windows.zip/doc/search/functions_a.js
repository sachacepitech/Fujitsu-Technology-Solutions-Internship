var searchData=
[
  ['remove_5fnewline_0',['remove_newline',['../load__usb__db__from__file_8c.html#a429655f2ccd8312615d99eae8a30dca4',1,'load_usb_db_from_file.c']]]
];
