var searchData=
[
  ['major_0',['major',['../structusb__risk__stats__s.html#aa53cf53c0a68f5a2ddde8d0990ee896f',1,'usb_risk_stats_s']]],
  ['medium_1',['medium',['../structusb__risk__stats__s.html#a972f3e21f5895ab975db2dc3b7318cbc',1,'usb_risk_stats_s']]]
];
