var searchData=
[
  ['fill_5fstruct_5ftemp_5fdata_0',['fill_struct_temp_data',['../load__usb__db__from__file_8c.html#a3da14dacce13ebb1a7161c95237207b2',1,'load_usb_db_from_file.c']]],
  ['free_5funknown_5fusb_5fdb_5fentry_1',['free_unknown_usb_db_entry',['../druid_8h.html#a6d4800679d14c175f9801e63b08b5063',1,'free_unknown_usb_db_entry(usb_db_entry_t *unknown):&#160;free_usb_db_entry.c'],['../free__usb__db__entry_8c.html#a6d4800679d14c175f9801e63b08b5063',1,'free_unknown_usb_db_entry(usb_db_entry_t *unknown):&#160;free_usb_db_entry.c']]],
  ['free_5fusb_5fdb_2',['free_usb_db',['../druid_8h.html#a75c16eea8808506b3484a278c2da13b4',1,'free_usb_db(usb_db_t *usb_db):&#160;free_usb_db_entry.c'],['../free__usb__db__entry_8c.html#a75c16eea8808506b3484a278c2da13b4',1,'free_usb_db(usb_db_t *usb_db):&#160;free_usb_db_entry.c']]],
  ['free_5fusb_5fdevice_5fand_5fdetails_3',['free_usb_device_and_details',['../scan__connected__usb__and__check__risks_8c.html#a3e3ba6f6da540bfbbf080bde96a78567',1,'scan_connected_usb_and_check_risks.c']]]
];
