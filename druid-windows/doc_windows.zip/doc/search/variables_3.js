var searchData=
[
  ['entries_0',['entries',['../structusb__db__s.html#aced193da1a75c1605d6bbb67b5a4e3eb',1,'usb_db_s']]]
];
