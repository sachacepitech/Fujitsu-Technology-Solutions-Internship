var indexSectionsWithContent =
{
  0: "acdefghilmnoprsuv",
  1: "cdsu",
  2: "defhilms",
  3: "acdefghilmrs",
  4: "acdeilmpsuv",
  5: "csu",
  6: "defhilmnoprsuv"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

